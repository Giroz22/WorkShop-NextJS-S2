package com.RiwiNotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiwiNotesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiwiNotesApplication.class, args);
	}

}
